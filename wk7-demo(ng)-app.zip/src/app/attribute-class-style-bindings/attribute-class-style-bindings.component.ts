import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attribute-class-style-bindings',
  templateUrl: './attribute-class-style-bindings.component.html',
  styleUrls: ['./attribute-class-style-bindings.component.css']
})
export class AttributeClassStyleBindingsComponent implements OnInit {

  headerSpan: number = 2;

  showWarning: boolean = false;

  grayBackground: string = "grey";

  showBackground: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

}
