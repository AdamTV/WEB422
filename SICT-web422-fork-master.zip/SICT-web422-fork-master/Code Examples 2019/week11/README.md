## Week 11 Example

The code example this week contains Four (4) separate solutions used to accompany the notes for this week, specifically:

### Simple-API

* simple-API (this is the starting point for the "Introduction to Securing a Web API with JWT" topic - it contains a node.js server)
* simple-API-complete (this is the completed version of the "simple-API" - used for reference)

### Simple-app

* simple-app (this is the starting point for the "Incorporating JWT in an Angular Application" topic - it contains an Angular app)
* simple-app-complete (this is the completed version of the "simple-app" - used for reference) 

