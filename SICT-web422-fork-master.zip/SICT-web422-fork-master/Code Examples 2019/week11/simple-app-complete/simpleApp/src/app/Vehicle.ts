export class Vehicle{
    id: number;
    year: number;
    make: string;
    model: string;
    vin: string;
}