import React from 'react';

import './App.css';

function App() {
  return (
    <div id="app">
      <nav id="menu">
        Menu goes here...
      </nav>

      <div id="bridge-info">
        Bridge info goes here
      </div>
    </div>
  );
}

export default App;
