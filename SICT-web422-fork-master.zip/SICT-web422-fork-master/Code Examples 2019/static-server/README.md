## Static Server

This is a simple server that will serve up everything in the "public" directory.  It does not contain any routes at all. 

This will be useful if we wish to push static content onto Heroku, as it provides a server framework for serving our (HTML, JS, CSS, image, etc..) files.

The public folder currently contains a single "index.html" file which references the bootstrap 3.3.7 JS/CSS and jQuery 3.2.1 JS files.
