import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eagle',
  templateUrl: './eagle.component.html',
  styleUrls: ['./eagle.component.css']
})
export class EagleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
