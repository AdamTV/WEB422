import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lizard',
  templateUrl: './lizard.component.html',
  styleUrls: ['./lizard.component.css']
})
export class LizardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
