import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dolphin',
  templateUrl: './dolphin.component.html',
  styleUrls: ['./dolphin.component.css']
})
export class DolphinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
