## Week 6 Example

The code example this week is a single application created in Angular using the Angular CLI 

This example illustrates how we can use Angular to position multiple components to create a complex (static) view

