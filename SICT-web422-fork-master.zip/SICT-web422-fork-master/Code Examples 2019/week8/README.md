## Week 8 Example

The code example this week is a continuation of the "Animals" examples from weeks 7 & 8. 

By following along with the code in this (completed) example, you will learn how to add and use a service in an app. 