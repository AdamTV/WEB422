<template>
  <div id="app">

    <nav id="menu">
      Menu goes here...
    </nav>

    <div id="bridge-info">
      Bridge info goes here...
    </div>

  </div>
</template>

<style>

</style>

<script>
export default {
  name: "App",
  data: function() {
    return {
    };
  }
};
</script>
