## Week 7 Example

The code example this week is a continuation of the "Animals" example from Week 7. 

This example illustrates how we can incorporate Angular routing in an application.