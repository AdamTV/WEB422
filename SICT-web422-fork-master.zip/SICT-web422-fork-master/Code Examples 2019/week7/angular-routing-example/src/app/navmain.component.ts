import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navmain',
  templateUrl: './navmain.component.html',
  styleUrls: ['./navmain.component.css']
})
export class NavmainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
