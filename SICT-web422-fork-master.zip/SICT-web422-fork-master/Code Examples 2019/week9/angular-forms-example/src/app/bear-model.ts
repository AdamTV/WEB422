export class BearModel {
    constructor (
        public code: string = '',
        public name: string = '',
        public hours: number = 0,
        public description: string = ''
    ) { }
}