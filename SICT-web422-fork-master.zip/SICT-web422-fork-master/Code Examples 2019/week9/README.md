## Week 9 Example

The code example this week is a continuation of the "Animals" examples from weeks 7, 8 & 9. 

By following along with the code in this (completed) example, you will learn how to add a simple "data-bound" form to the "Bear" Component using the techniques discussed in class.