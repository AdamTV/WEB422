<h3>Project Template</h3>
<p>Features:</p>
<ul>
  <li>Node.js and Express.js</li>
  <li>No database, no data - just string responses from the Express.js methods</li>
</ul>

<br>

### How to get started with this template

Copy and paste the project template *folder*, and rename the new folder as you wish. 

In a new CLI (command line interface), navigate to the project folder.  
Run `npm init` to update the name and any other values you wish to update.  
Run `npm i` to rebuild the packages it needs.  

Start/run the server.  
Test with Postman.

<br>
