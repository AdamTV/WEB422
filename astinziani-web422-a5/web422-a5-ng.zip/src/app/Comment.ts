export class Comment{
 _id: string
 author: string;
 comment: string;
 date: string;
}