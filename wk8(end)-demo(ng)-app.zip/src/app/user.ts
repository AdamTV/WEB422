export class User {
  firstName: string;
  email: string;
  age: number;
  language: string;
  active: boolean;
}
